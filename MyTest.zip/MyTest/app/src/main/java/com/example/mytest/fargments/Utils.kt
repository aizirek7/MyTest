package com.example.mytest.fargments

object Utils {
    const val ShearedPref = "shearedPref"
    const val TAG = "TAG"
    const val KEY_FOR_SP = "key"
    const val URL = "https://hirelmany.online/RxZygwC2"
    const val URL_FROM_URL = "url"
    const val SCORE = "score"
}